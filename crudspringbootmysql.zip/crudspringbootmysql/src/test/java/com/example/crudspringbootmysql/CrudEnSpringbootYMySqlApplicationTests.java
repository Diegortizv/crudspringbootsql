package com.example.crudspringbootmysql;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudEnSpringbootYMySqlApplicationTests {

	@Test
	void contextLoads() {
	}

}
