package com.example.crudspringbootmysql;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudEnSpringbootYMySqlApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudEnSpringbootYMySqlApplication.class, args);
	}

}
